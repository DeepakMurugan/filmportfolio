globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx+unenv.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/arrow-right-DuXN2p83.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-Es4++K9r5mREemdCrr4lOU+Rzqg\"",
		"mtime": "2026-07-02T14:03:36.002Z",
		"size": 155,
		"path": "../public/assets/arrow-right-DuXN2p83.js"
	},
	"/assets/check-CblO0h89.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"72-WOmzVwIiduRjnRzfVwRrz0RxKq8\"",
		"mtime": "2026-07-02T14:03:36.005Z",
		"size": 114,
		"path": "../public/assets/check-CblO0h89.js"
	},
	"/assets/award-BpdRik_O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"108-MxflPSjGwP54i3AGhTbummiVzAw\"",
		"mtime": "2026-07-02T14:03:36.003Z",
		"size": 264,
		"path": "../public/assets/award-BpdRik_O.js"
	},
	"/assets/about-DTDMLLZ3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"193a-26YZ/SpFU90jJwwDdqXpchYv2Ic\"",
		"mtime": "2026-07-02T14:03:36.001Z",
		"size": 6458,
		"path": "../public/assets/about-DTDMLLZ3.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4\"",
		"mtime": "2026-07-02T12:37:31.000Z",
		"size": 23,
		"path": "../public/robots.txt"
	},
	"/assets/experience-CDt3ORdU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13a7-a29o0GW6f/7e0JbgSmBUEvCVc1g\"",
		"mtime": "2026-07-02T14:03:36.008Z",
		"size": 5031,
		"path": "../public/assets/experience-CDt3ORdU.js"
	},
	"/assets/Footer-CFJ1hgdg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38dd-KMH3GJVMobXhCt3HEAckPyW78qE\"",
		"mtime": "2026-07-02T14:03:35.997Z",
		"size": 14557,
		"path": "../public/assets/Footer-CFJ1hgdg.js"
	},
	"/assets/contact-BGtOwRYe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f4da-XC5E1tKe8KQzz0Kw0Ak+EyikSf4\"",
		"mtime": "2026-07-02T14:03:36.006Z",
		"size": 62682,
		"path": "../public/assets/contact-BGtOwRYe.js"
	},
	"/assets/film-fTdh6aRe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d-gEIm90TX4weX/LbsQDN+jtK7en8\"",
		"mtime": "2026-07-02T14:03:36.008Z",
		"size": 397,
		"path": "../public/assets/film-fTdh6aRe.js"
	},
	"/assets/plane-BDpm7dt5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"128-HDiOSmKqNV/OWv5/RMwR6ksU/qQ\"",
		"mtime": "2026-07-02T14:03:36.010Z",
		"size": 296,
		"path": "../public/assets/plane-BDpm7dt5.js"
	},
	"/assets/play-CjTvxqNK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-2WwYocxfMo/LKWuuJk5xr+LXCko\"",
		"mtime": "2026-07-02T14:03:36.011Z",
		"size": 180,
		"path": "../public/assets/play-CjTvxqNK.js"
	},
	"/assets/Reveal-DfY4kqje.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"270-iSIV1NM2+mxk2Gkk++tLZUr1RP0\"",
		"mtime": "2026-07-02T14:03:36.000Z",
		"size": 624,
		"path": "../public/assets/Reveal-DfY4kqje.js"
	},
	"/assets/camera-wTwBqAh2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"146-Ey6+mNQ+PfxauiM738OFpXfoQtE\"",
		"mtime": "2026-07-02T14:03:36.004Z",
		"size": 326,
		"path": "../public/assets/camera-wTwBqAh2.js"
	},
	"/assets/portfolio-BBR1_SFS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1382-96uFh23i/sIJhVhxjqDF0vHhxGE\"",
		"mtime": "2026-07-02T14:03:36.011Z",
		"size": 4994,
		"path": "../public/assets/portfolio-BBR1_SFS.js"
	},
	"/assets/PageHero-CcxAWBgb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"77b-PaAhwL8gUywj4uyFVLE5d9ttxpQ\"",
		"mtime": "2026-07-02T14:03:35.998Z",
		"size": 1915,
		"path": "../public/assets/PageHero-CcxAWBgb.js"
	},
	"/assets/services-BA-ZWH07.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"310a-r1q+CLaqVfxdEZdH8BC62NdLZxE\"",
		"mtime": "2026-07-02T14:03:36.011Z",
		"size": 12554,
		"path": "../public/assets/services-BA-ZWH07.js"
	},
	"/assets/index-CNRE88Dd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56935-+EeY76wwTlvWSDDSeNxDV4aZAV4\"",
		"mtime": "2026-07-02T14:03:35.995Z",
		"size": 354613,
		"path": "../public/assets/index-CNRE88Dd.js"
	},
	"/assets/sparkles-U_MDQU1s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4-S4MMoXg7edFM0Kx824bxfD6lLGs\"",
		"mtime": "2026-07-02T14:03:36.011Z",
		"size": 484,
		"path": "../public/assets/sparkles-U_MDQU1s.js"
	},
	"/assets/routes-BzFyG1yR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4bd8-zO4NMAyB7COeeYDghxF2v316ALY\"",
		"mtime": "2026-07-02T14:03:36.011Z",
		"size": 19416,
		"path": "../public/assets/routes-BzFyG1yR.js"
	},
	"/assets/styles-Bxsdyus9.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a73f-N74uuA411JfRLbNUVeeGrHnDDEQ\"",
		"mtime": "2026-07-02T14:03:36.019Z",
		"size": 108351,
		"path": "../public/assets/styles-Bxsdyus9.css"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_tFYzdo = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_tFYzdo
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
