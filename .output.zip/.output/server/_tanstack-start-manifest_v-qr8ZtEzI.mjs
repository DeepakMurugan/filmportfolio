//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-qr8ZtEzI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/experience",
			"/portfolio",
			"/services",
			"/sitemap.xml"
		],
		preloads: ["/assets/index-CNRE88Dd.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CNRE88Dd.js"
		} }]
	},
	"/": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BzFyG1yR.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/arrow-right-DuXN2p83.js",
			"/assets/award-BpdRik_O.js",
			"/assets/camera-wTwBqAh2.js",
			"/assets/film-fTdh6aRe.js",
			"/assets/play-CjTvxqNK.js",
			"/assets/Reveal-DfY4kqje.js"
		]
	},
	"/about": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DTDMLLZ3.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/award-BpdRik_O.js",
			"/assets/camera-wTwBqAh2.js",
			"/assets/film-fTdh6aRe.js",
			"/assets/sparkles-U_MDQU1s.js",
			"/assets/PageHero-CcxAWBgb.js",
			"/assets/Reveal-DfY4kqje.js"
		]
	},
	"/contact": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BGtOwRYe.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/check-CblO0h89.js",
			"/assets/PageHero-CcxAWBgb.js",
			"/assets/Reveal-DfY4kqje.js"
		]
	},
	"/experience": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/experience.tsx",
		children: void 0,
		preloads: [
			"/assets/experience-CDt3ORdU.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/camera-wTwBqAh2.js",
			"/assets/plane-BDpm7dt5.js",
			"/assets/PageHero-CcxAWBgb.js",
			"/assets/Reveal-DfY4kqje.js"
		]
	},
	"/portfolio": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio-BBR1_SFS.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/play-CjTvxqNK.js",
			"/assets/PageHero-CcxAWBgb.js"
		]
	},
	"/services": {
		filePath: "C:/dee/portfolio client/port/rajen/portfolio/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BA-ZWH07.js",
			"/assets/Footer-CFJ1hgdg.js",
			"/assets/arrow-right-DuXN2p83.js",
			"/assets/camera-wTwBqAh2.js",
			"/assets/check-CblO0h89.js",
			"/assets/film-fTdh6aRe.js",
			"/assets/plane-BDpm7dt5.js",
			"/assets/sparkles-U_MDQU1s.js",
			"/assets/PageHero-CcxAWBgb.js",
			"/assets/Reveal-DfY4kqje.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
