import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PageHero-vruvWOX5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PageHero({ eyebrow, title, subtitle, children }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		let raf = 0;
		const onScroll = () => {
			cancelAnimationFrame(raf);
			raf = requestAnimationFrame(() => {
				const y = Math.min(window.scrollY, 600);
				el.style.setProperty("--py", `${y * .18}px`);
				el.style.setProperty("--pyo", `${1 - Math.min(1, y / 500)}`);
			});
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		ref,
		className: "relative pt-28 pb-14 sm:pt-36 sm:pb-20 lg:pt-44 lg:pb-28 overflow-hidden film-grain section-amber",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute -top-32 -right-32 w-[34rem] h-[34rem] rounded-full blur-[120px] opacity-[0.18] orb-drift",
				style: { background: "radial-gradient(circle, var(--gold), transparent 60%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute -bottom-40 -left-32 w-[28rem] h-[28rem] rounded-full blur-[120px] opacity-[0.12] orb-drift",
				style: {
					background: "radial-gradient(circle, oklch(0.7 0.14 60), transparent 60%)",
					animationDelay: "-6s"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x relative",
				style: {
					transform: "translateY(calc(var(--py, 0px) * -1))",
					opacity: "var(--pyo, 1)"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10px] sm:text-xs tracking-[0.4em] uppercase text-gold mb-5 sm:mb-6 reveal-up flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-8 h-px bg-gold/60" }), eyebrow]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[2.6rem] leading-[1.02] sm:text-6xl md:text-7xl lg:text-8xl max-w-5xl reveal-up",
						style: { animationDelay: "120ms" },
						children: title
					}),
					subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 sm:mt-8 max-w-2xl text-base sm:text-lg text-muted-foreground reveal-up leading-relaxed",
						style: { animationDelay: "240ms" },
						children: subtitle
					}),
					children
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 inset-x-0 gold-divider" })
		]
	});
}
//#endregion
export { PageHero as t };
