import { n as __toESM } from "../_runtime.mjs";
import { c as performance_default } from "../_libs/h3+rou3+srvx+unenv.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Award, S as Camera, T as ArrowRight, c as Play, o as Quote, y as Film } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as Reveal } from "./Reveal-hdzIZTDg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CGpp2lb0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Cinematic galaxy / starfield canvas.
* - Moving stars (parallax layers)
* - Warm gold nebula clouds matching theme
* - Occasional shooting star
* Fully responsive, DPR-aware, respects reduced-motion.
*/
function GalaxyBackground({ className = "" }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		let w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
		let stars = [];
		let shoot = null;
		const resize = () => {
			w = canvas.clientWidth;
			h = canvas.clientHeight;
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			const density = Math.min(1, w * h / (1920 * 1080));
			const count = Math.floor(220 * density) + 80;
			stars = Array.from({ length: count }, () => ({
				x: Math.random() * w,
				y: Math.random() * h,
				z: Math.random() * .9 + .1,
				r: Math.random() * 1.3 + .2,
				tw: Math.random() * Math.PI * 2,
				tp: Math.random() * .02 + .005
			}));
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		const nebula = document.createElement("canvas");
		const nctx = nebula.getContext("2d");
		const renderNebula = () => {
			nebula.width = w;
			nebula.height = h;
			[
				{
					x: w * .15,
					y: h * .25,
					r: Math.max(w, h) * .55,
					c: "rgba(198,169,105,0.18)"
				},
				{
					x: w * .85,
					y: h * .75,
					r: Math.max(w, h) * .6,
					c: "rgba(180,130,70,0.14)"
				},
				{
					x: w * .6,
					y: h * .15,
					r: Math.max(w, h) * .45,
					c: "rgba(120,90,160,0.10)"
				},
				{
					x: w * .3,
					y: h * .85,
					r: Math.max(w, h) * .5,
					c: "rgba(80,60,120,0.10)"
				}
			].forEach((b) => {
				const g = nctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
				g.addColorStop(0, b.c);
				g.addColorStop(1, "rgba(0,0,0,0)");
				nctx.fillStyle = g;
				nctx.fillRect(0, 0, w, h);
			});
		};
		const roN = new ResizeObserver(renderNebula);
		roN.observe(canvas);
		renderNebula();
		let raf = 0;
		let last = performance_default.now();
		let mouseX = 0, mouseY = 0, tx = 0, ty = 0;
		const onMouse = (e) => {
			const rect = canvas.getBoundingClientRect();
			mouseX = (e.clientX - rect.left - w / 2) / w;
			mouseY = (e.clientY - rect.top - h / 2) / h;
		};
		window.addEventListener("mousemove", onMouse);
		const tick = (now) => {
			const dt = Math.min(50, now - last);
			last = now;
			tx += (mouseX * 20 - tx) * .04;
			ty += (mouseY * 20 - ty) * .04;
			ctx.clearRect(0, 0, w, h);
			const bg = ctx.createLinearGradient(0, 0, 0, h);
			bg.addColorStop(0, "#05050a");
			bg.addColorStop(1, "#080808");
			ctx.fillStyle = bg;
			ctx.fillRect(0, 0, w, h);
			ctx.drawImage(nebula, 0, 0);
			for (const s of stars) {
				if (!reduced) {
					s.x += (.02 + s.z * .06) * (dt / 16);
					s.tw += s.tp * (dt / 16);
				}
				if (s.x > w + 4) s.x = -4;
				const px = s.x + tx * s.z;
				const py = s.y + ty * s.z;
				const a = .4 + Math.sin(s.tw) * .35 + s.z * .25;
				const rad = s.r * (.6 + s.z);
				ctx.beginPath();
				ctx.fillStyle = `rgba(255,240,210,${Math.max(0, Math.min(1, a))})`;
				ctx.arc(px, py, rad, 0, Math.PI * 2);
				ctx.fill();
				if (s.z > .75) {
					ctx.beginPath();
					ctx.fillStyle = `rgba(198,169,105,${a * .25})`;
					ctx.arc(px, py, rad * 3, 0, Math.PI * 2);
					ctx.fill();
				}
			}
			if (!reduced) {
				if (!shoot && Math.random() < .004) shoot = {
					x: -50,
					y: Math.random() * h * .6,
					vx: 8 + Math.random() * 6,
					vy: 2 + Math.random() * 2,
					life: 0,
					max: 80
				};
				if (shoot) {
					shoot.x += shoot.vx;
					shoot.y += shoot.vy;
					shoot.life += 1;
					const grad = ctx.createLinearGradient(shoot.x - shoot.vx * 12, shoot.y - shoot.vy * 12, shoot.x, shoot.y);
					grad.addColorStop(0, "rgba(198,169,105,0)");
					grad.addColorStop(1, "rgba(255,240,210,0.9)");
					ctx.strokeStyle = grad;
					ctx.lineWidth = 1.4;
					ctx.beginPath();
					ctx.moveTo(shoot.x - shoot.vx * 12, shoot.y - shoot.vy * 12);
					ctx.lineTo(shoot.x, shoot.y);
					ctx.stroke();
					if (shoot.life > shoot.max || shoot.x > w + 60) shoot = null;
				}
			}
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			roN.disconnect();
			window.removeEventListener("mousemove", onMouse);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		"aria-hidden": true,
		className: `absolute inset-0 w-full h-full ${className}`
	});
}
var hero_mp4_asset_default = {
	version: 1,
	asset_id: "f3131b20-59d4-4e5d-8466-3acbe268bd10",
	project_id: "885eb323-5dd5-48b0-9ef4-36b1434aaef1",
	url: "/__l5e/assets-v1/f3131b20-59d4-4e5d-8466-3acbe268bd10/hero.mp4",
	r2_key: "a/v1/885eb323-5dd5-48b0-9ef4-36b1434aaef1/f3131b20-59d4-4e5d-8466-3acbe268bd10/hero.mp4",
	original_filename: "hero.mp4",
	size: 9332341,
	content_type: "video/mp4",
	created_at: "2026-06-22T17:20:08Z"
};
var brands = [
	"Taj Hotels",
	"ITC Grand",
	"Manyavar",
	"Tanishq",
	"Kalyan Jewellers",
	"Sabyasachi",
	"JW Marriott",
	"Leela Palace",
	"Lulu Group",
	"Vogue India"
];
var films = [
	{
		title: "Ananya & Rohan",
		category: "Wedding Film",
		big: true,
		img: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80"
	},
	{
		title: "Priya & Karthik",
		category: "Pre Wedding",
		big: true,
		img: "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=1200&q=80"
	},
	{
		title: "Aerial Symphony",
		category: "FPV Drone",
		big: false,
		img: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=900&q=80"
	},
	{
		title: "Tanishq Heritage",
		category: "Commercial",
		big: false,
		img: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=900&q=80"
	},
	{
		title: "Coldplay Chennai",
		category: "Concert",
		big: false,
		img: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=900&q=80"
	}
];
var signatures = [
	{
		t: "Documentary Storytelling",
		d: "Real emotions caught in motion. No staged poses, only truths.",
		icon: Film
	},
	{
		t: "Cinematic Composition",
		d: "Film-level framing, color, and light — every frame a still.",
		icon: Camera
	},
	{
		t: "FPV Drone Mastery",
		d: "Immersive aerial choreography that moves through the moment.",
		icon: Award
	},
	{
		t: "Emotional Narratives",
		d: "Moments that stay forever, edited with rhythm and restraint.",
		icon: Quote
	}
];
var stats = [
	{
		n: 8,
		suf: "+",
		label: "Years of Craft"
	},
	{
		n: 100,
		suf: "+",
		label: "Films Delivered"
	},
	{
		n: 50,
		suf: "+",
		label: "Couples Filmed"
	},
	{
		n: 20,
		suf: "+",
		label: "Brands Trusted"
	}
];
var gear = [
	{
		name: "Sony Alpha 7 IV",
		type: "Cinema Body",
		spec: "33MP · 4K 60p · S-Cinetone"
	},
	{
		name: "DJI RS 4 Pro",
		type: "Stabilizer",
		spec: "3-axis · 4.5kg payload"
	},
	{
		name: "DJI FPV Avata 2",
		type: "FPV Drone",
		spec: "4K 100fps · sub-200g cinewhoop"
	},
	{
		name: "RØDE Wireless GO II",
		type: "Audio",
		spec: "Dual channel · 32-bit float"
	},
	{
		name: "Sigma 24-70mm f/2.8",
		type: "Lens",
		spec: "Art series · DG DN"
	}
];
var testimonials = [
	{
		q: "Every emotion was captured beautifully. Watching our film felt like reliving the day, frame by frame.",
		n: "Ananya & Rohan",
		e: "Wedding · Chennai"
	},
	{
		q: "Rajendraprasath has an eye for the unseen. The FPV shots gave our wedding a cinematic dimension we never imagined.",
		n: "Priya & Karthik",
		e: "Destination · Udaipur"
	},
	{
		q: "Effortlessly professional. The team disappears into the day, then returns with a masterpiece.",
		n: "Meera & Arjun",
		e: "Wedding · Coimbatore"
	}
];
function Counter({ to, suf }) {
	const ref = (0, import_react.useRef)(null);
	const [val, setVal] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) {
					const start = performance_default.now();
					const dur = 1800;
					const tick = (now) => {
						const p = Math.min(1, (now - start) / dur);
						const eased = 1 - Math.pow(1 - p, 3);
						setVal(Math.round(to * eased));
						if (p < 1) requestAnimationFrame(tick);
					};
					requestAnimationFrame(tick);
					io.disconnect();
				}
			});
		});
		io.observe(el);
		return () => io.disconnect();
	}, [to]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		children: [val, suf]
	});
}
function Home() {
	const [tIdx, setTIdx] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setTIdx((i) => (i + 1) % testimonials.length), 6e3);
		return () => clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative h-[100dvh] min-h-[620px] sm:min-h-[720px] w-full overflow-hidden film-grain",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalaxyBackground, { className: "z-0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					src: hero_mp4_asset_default.url,
					autoPlay: true,
					muted: true,
					loop: true,
					playsInline: true,
					className: "absolute inset-0 w-full h-full object-cover slow-zoom opacity-40 mix-blend-screen z-[1]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 z-[2] bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(0,0,0,0.75)_100%)]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 z-[2] bg-gradient-to-b from-transparent via-background/10 to-background" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative z-10 h-full container-x flex flex-col justify-end pt-28 sm:pt-32 pb-20 sm:pb-24 lg:pb-32",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-12 gap-8 sm:gap-12 items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] sm:text-xs tracking-[0.35em] sm:tracking-[0.4em] uppercase text-gold mb-4 sm:mb-6 reveal-up",
									children: "Wedding Cinematographer · Chennai"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "font-display text-[11.5vw] sm:text-[10vw] lg:text-[6.5vw] leading-[1.05] sm:leading-[0.95] tracking-tight reveal-up",
									style: { animationDelay: "120ms" },
									children: [
										"Capturing Love",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "gold-gradient-text italic font-light",
											children: "Beyond Frames"
										}),
										" & Time"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 sm:mt-8 max-w-xl text-base sm:text-lg text-muted-foreground reveal-up",
									style: { animationDelay: "260ms" },
									children: "Documentary-led wedding films crafted with cinematic storytelling, emotion, and timeless visual elegance."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 sm:mt-10 flex flex-wrap gap-3 sm:gap-4 reveal-up",
									style: { animationDelay: "400ms" },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/portfolio",
										className: "group inline-flex items-center gap-3 px-6 sm:px-7 py-3.5 sm:py-4 bg-gold text-gold-foreground text-xs sm:text-sm tracking-[0.2em] uppercase hover:bg-gold/90 transition-all",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 14 }), " Watch Films"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/contact",
										className: "group inline-flex items-center gap-3 px-6 sm:px-7 py-3.5 sm:py-4 border border-foreground/30 text-foreground text-xs sm:text-sm tracking-[0.2em] uppercase hover:border-gold hover:text-gold transition-all",
										children: ["Book Consultation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
											size: 14,
											className: "group-hover:translate-x-1 transition-transform"
										})]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-4 grid grid-cols-3 gap-3 reveal-up",
							style: { animationDelay: "540ms" },
							children: [
								{
									n: "8+",
									l: "Years"
								},
								{
									n: "100+",
									l: "Films"
								},
								{
									n: "FPV",
									l: "Specialist"
								}
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-card p-4 sm:p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl sm:text-3xl text-gold",
									children: s.n
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] tracking-[0.25em] uppercase text-muted-foreground mt-2",
									children: s.l
								})]
							}, s.l))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-5 sm:bottom-6 left-1/2 -translate-x-1/2 z-10 text-[10px] tracking-[0.4em] uppercase text-muted-foreground animate-pulse",
					children: "Scroll"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-14 border-y border-border overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex marquee-track whitespace-nowrap",
				children: [...brands, ...brands].map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-12 font-display text-2xl text-muted-foreground/60 hover:text-gold transition-colors",
					children: b
				}, i))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-12 gap-12 lg:gap-16 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-[4/5] overflow-hidden rounded-2xl gold-sheen",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "src/assets/admin.jpeg",
							alt: "Rajendraprasath, cinematographer",
							className: "w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 hover:scale-105"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 ring-1 ring-inset ring-gold/20 rounded-2xl pointer-events-none" })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 150,
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tracking-[0.4em] uppercase text-gold mb-6 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-8 h-px bg-gold/60" }), "The Filmmaker"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl md:text-5xl lg:text-6xl mb-8",
							children: [
								"Stories that breathe,",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "gold-gradient-text italic font-light",
									children: "frames that last."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg text-muted-foreground leading-relaxed",
							children: "Rajendraprasath is a Chennai-based cinematographer and wedding filmmaker with 8+ years of experience crafting deeply emotional films that preserve real moments with cinematic elegance."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg text-muted-foreground leading-relaxed mt-4",
							children: "His work blends documentary instinct with the discipline of feature filmmaking — patient, observant, and unafraid of silence."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/about",
							className: "mt-10 inline-flex items-center gap-3 text-gold text-sm tracking-[0.25em] uppercase link-gold",
							children: ["Read the full story ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 14 })]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y container-x",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 md:mb-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "Featured Work"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl",
					children: "Selected Films"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/portfolio",
					className: "text-sm tracking-[0.25em] uppercase text-muted-foreground hover:text-gold inline-flex items-center gap-2 link-gold",
					children: ["View All ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 14 })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-12 gap-4 lg:gap-6",
				children: films.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					className: f.big ? "col-span-12 md:col-span-6" : "col-span-12 sm:col-span-6 md:col-span-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/portfolio",
						className: "group block relative overflow-hidden aspect-[4/3] rounded-2xl gold-sheen",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: f.img,
								alt: f.title,
								loading: "lazy",
								className: "absolute inset-0 w-full h-full object-cover transition-transform duration-[1400ms] group-hover:scale-110"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-background/0 group-hover:bg-background/40 transition-colors duration-500" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 grid place-items-center opacity-0 group-hover:opacity-100 transition-opacity duration-500",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-16 h-16 rounded-full bg-gold/95 text-gold-foreground grid place-items-center gold-pulse",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										size: 20,
										className: "ml-1",
										fill: "currentColor"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-0 left-0 p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-2",
									children: f.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl lg:text-3xl",
									children: f.title
								})]
							})
						]
					})
				}, f.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y section-gold-veil border-y border-white/[0.05]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4 text-center",
					children: "Signature Style"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl text-center max-w-3xl mx-auto",
					children: [
						"A craft built on ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "gold-gradient-text italic font-light",
							children: "instinct"
						}),
						" and intent."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 md:mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-5",
					children: signatures.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 100,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group relative h-full p-8 rounded-2xl border border-white/[0.06] bg-card hover:border-gold/50 transition-all duration-500 hover-lift overflow-hidden",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
									className: "text-gold group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500",
									size: 28
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl mt-6",
									children: s.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground mt-3 text-[15px] leading-relaxed",
									children: s.d
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-0 -z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500",
									style: { background: "radial-gradient(circle at 50% 0%, rgba(198,169,105,0.16), transparent 70%)" }
								})
							]
						})
					}, s.t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-y-10 gap-x-6",
				children: stats.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: i * 80,
					className: "text-center border-l border-white/[0.06] first:border-l-0 lg:border-l",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-5xl md:text-6xl lg:text-7xl gold-gradient-text",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
							to: s.n,
							suf: s.suf
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs tracking-[0.3em] uppercase text-muted-foreground",
						children: s.label
					})]
				}, s.label))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y section-noir border-t border-white/[0.06]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x mb-10 md:mb-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "The Kit"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl max-w-2xl",
					children: "Tools chosen with intention."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-5 md:gap-6 overflow-x-auto pb-8 px-5 md:px-10 snap-x snap-mandatory",
				children: gear.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "snap-start shrink-0 w-[300px] md:w-[380px] p-8 bg-card rounded-2xl border border-white/[0.06] hover:border-gold/40 transition-all duration-500 hover gold-sheen",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] tracking-[0.3em] uppercase text-gold",
							children: g.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl md:text-3xl mt-4",
							children: g.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground mt-3 text-sm",
							children: g.spec
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
							className: "mt-12 text-muted-foreground/40",
							size: 48,
							strokeWidth: 1
						})
					]
				}, g.name))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y section-gold-veil border-y border-white/[0.05]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4 text-center",
					children: "In Their Words"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl text-center mb-12 md:mb-20",
					children: "Loved by couples."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-4xl mx-auto glass-card rounded-2xl p-8 md:p-14 lg:p-16 relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
							className: "absolute -top-6 left-10 text-gold bg-background px-2",
							size: 48
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal-up",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-xl md:text-3xl leading-snug italic text-foreground/95",
								children: [
									"\"",
									testimonials[tIdx].q,
									"\""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-10 bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: testimonials[tIdx].n
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tracking-[0.2em] uppercase text-muted-foreground mt-1",
									children: testimonials[tIdx].e
								})] })]
							})]
						}, tIdx),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2 mt-10",
							children: testimonials.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": `Testimonial ${i + 1}`,
								onClick: () => setTIdx(i),
								className: `h-px transition-all ${i === tIdx ? "w-12 bg-gold" : "w-6 bg-border"}`
							}, i))
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative py-24 md:py-32 lg:py-40 overflow-hidden film-grain",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					src: hero_mp4_asset_default.url,
					autoPlay: true,
					muted: true,
					loop: true,
					playsInline: true,
					className: "absolute inset-0 w-full h-full object-cover opacity-30"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-background via-background/70 to-background" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0",
					style: { background: "radial-gradient(ellipse at center, rgba(198,169,105,0.18), transparent 60%)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative container-x text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.4em] uppercase text-gold mb-6",
							children: "Let's Begin"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl sm:text-5xl md:text-7xl lg:text-8xl leading-[1] max-w-4xl mx-auto",
							children: [
								"Let's create something",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "gold-gradient-text italic font-light",
									children: "timeless."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							className: "mt-10 md:mt-12 inline-flex items-center gap-3 px-10 py-5 bg-gold text-gold-foreground text-sm tracking-[0.25em] uppercase hover:bg-gold/90 transition-all rounded-full gold-pulse gold-sheen",
							children: ["Book Your Story ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 14 })]
						})
					] })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
//#endregion
export { Home as component };
