import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Award, S as Camera, i as Sparkles, v as Heart, y as Film } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as PageHero } from "./PageHero-vruvWOX5.mjs";
import { t as Reveal } from "./Reveal-hdzIZTDg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DI_3I4HT.js
var import_jsx_runtime = require_jsx_runtime();
var timeline = [
	{
		year: "2017",
		title: "First Frame",
		body: "Picked up a camera at a friend's wedding. Never looked back."
	},
	{
		year: "2019",
		title: "Studio Founded",
		body: "Started Rajendraprasath Films with a documentary-first manifesto."
	},
	{
		year: "2021",
		title: "FPV Specialisation",
		body: "Added FPV drone cinematography — a signature ever since."
	},
	{
		year: "2023",
		title: "100 Films",
		body: "Crossed the hundred-film mark across India and abroad."
	},
	{
		year: "2025",
		title: "Premium Studio",
		body: "A small team. Big stories. Selective collaborations only."
	}
];
var skills = [
	{
		icon: Film,
		t: "Cinematography"
	},
	{
		icon: Camera,
		t: "Direction"
	},
	{
		icon: Sparkles,
		t: "Colour Grading"
	},
	{
		icon: Heart,
		t: "Emotional Editing"
	},
	{
		icon: Award,
		t: "FPV Drone"
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "The Filmmaker",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"Eight years of ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gold-gradient-text italic font-light",
					children: "listening"
				}),
				" through a lens."
			] }),
			subtitle: "Rajendraprasath is a Chennai-based cinematographer and wedding filmmaker. His work is patient, observant, and deeply emotional — the kind of films couples revisit on every anniversary."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y container-x grid lg:grid-cols-12 gap-12 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "lg:col-span-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "aspect-[4/5] overflow-hidden rounded-2xl gold-sheen relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "src/assets/admin.jpeg",
						alt: "Rajendraprasath portrait",
						className: "w-full h-full object-cover transition-transform duration-[1400ms] hover:scale-105"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 ring-1 ring-inset ring-gold/20 rounded-2xl pointer-events-none" })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 150,
				className: "lg:col-span-7 space-y-6 text-lg text-muted-foreground leading-relaxed",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I grew up loving cinema way before I loved cameras. The pull of a single shot the way light catches a smile is exactly why I film weddings. To me, your day isn’t just an event; it’s a living story that deserves to be filmed like a movie." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "My approach is entirely documentary at heart, meaning no awkward, staged poses. I watch for those quiet, unscripted moments the joyful chaos and the secret glances - and frame them beautifully so the final piece feels like a core memory you can return to." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You’re getting over eight years of experience, To maintain this level of artistry, my trusted team takes on a limited number of weddings each year so every film gets the absolute focus it deserves." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To bring a unique perspective, I also fly custom-built FPV drones for immersive aerial shots. This lets me mix intimate ground emotions with breathtaking cinematic angles, creating a timeless film where you don't just watch the day, but feel the butterflies all over again." }),
					"   "
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y section-gold-veil border-y border-white/[0.05]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "Career Timeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl mb-12 md:mb-16",
					children: "The road so far."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-[7.5rem] top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gold/50 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-10 md:space-y-12",
						children: timeline.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-12 items-baseline group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-24 shrink-0 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl gold-gradient-text",
										children: t.year
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative pl-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-[-5px] top-2.5 w-2.5 h-2.5 rounded-full bg-gold ring-4 ring-gold/15 group-hover:ring-gold/30 transition-all" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-2xl group-hover:text-gold transition-colors",
											children: t.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-muted-foreground mt-2",
											children: t.body
										})
									]
								})]
							})
						}, t.year))
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y container-x",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
				children: "Craft"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl md:text-5xl lg:text-6xl mb-10 md:mb-12",
				children: "What I bring to set."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 lg:grid-cols-5 gap-4",
				children: skills.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group relative p-8 rounded-2xl border border-white/[0.06] bg-card hover:border-gold/40 transition-all duration-500 hover-lift overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none",
								style: { background: "radial-gradient(circle at 50% 0%, rgba(198,169,105,0.14), transparent 70%)" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
								className: "text-gold mb-6 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500",
								size: 28
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl relative",
								children: s.t
							})
						]
					})
				}, s.t))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y container-x text-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-4xl md:text-5xl lg:text-6xl max-w-3xl mx-auto",
				children: ["Let's talk about ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gold-gradient-text italic font-light",
					children: "your film."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/contact",
				className: "mt-10 inline-flex items-center gap-3 px-8 py-4 bg-gold text-gold-foreground text-sm tracking-[0.25em] uppercase hover:bg-gold/90 transition-all rounded-full gold-pulse gold-sheen",
				children: "Start a Conversation"
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
//#endregion
export { AboutPage as component };
