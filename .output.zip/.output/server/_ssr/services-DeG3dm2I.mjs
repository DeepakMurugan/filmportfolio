import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Camera, T as ArrowRight, b as Clapperboard, d as Music, f as Minus, i as Sparkles, l as Plane, s as Plus, w as ArrowUpRight, x as Check, y as Film } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as PageHero } from "./PageHero-vruvWOX5.mjs";
import { t as Reveal } from "./Reveal-hdzIZTDg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-DeG3dm2I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var services = [
	{
		icon: Film,
		title: "Wedding Films",
		pitch: "A documentary-led, cinematic feature of your wedding day — paced like a film, edited with restraint.",
		deliverables: [
			"8–12 min cinematic film",
			"60–90s teaser trailer",
			"Full-day coverage",
			"Colour-graded master in 4K"
		],
		from: "₹2,50,000"
	},
	{
		icon: Camera,
		title: "Pre-Wedding Shoots",
		pitch: "Intimate, location-led stories that capture your couplehood before the day arrives.",
		deliverables: [
			"Half-day or full-day shoot",
			"3–5 min cinematic film",
			"Location scouting",
			"Two outfit changes"
		],
		from: "₹85,000"
	},
	{
		icon: Plane,
		title: "Drone & FPV Cinematography",
		pitch: "Sweeping aerial and immersive FPV sequences that move through your venue like a feature film.",
		deliverables: [
			"Licensed pilot",
			"DJI Avata 2 + Mavic 3",
			"Up to 4 sequences",
			"Raw + edited delivery"
		],
		from: "₹65,000"
	},
	{
		icon: Clapperboard,
		title: "Commercial Films",
		pitch: "Brand films, product shoots, and campaign content with the same cinematic discipline.",
		deliverables: [
			"Pre-production & treatment",
			"Direction & DOP",
			"Edit, grade & sound",
			"Multi-format delivery"
		],
		from: "On request"
	},
	{
		icon: Music,
		title: "Event Coverage",
		pitch: "Concerts, launches, conferences — captured with multi-cam coverage and quick-turn highlight reels.",
		deliverables: [
			"Multi-cam setup",
			"Live audio capture",
			"24h highlight reel",
			"Full edit within 14 days"
		],
		from: "₹1,20,000"
	}
];
var process = [
	{
		n: "01",
		t: "Discovery Call",
		d: "We talk through your story, venues, key moments, and the feeling you want the film to carry."
	},
	{
		n: "02",
		t: "Treatment & Plan",
		d: "A custom shoot plan, timeline, and creative treatment tailored to your day."
	},
	{
		n: "03",
		t: "On The Day",
		d: "Documentary presence — we move with the moment, never staging or interrupting."
	},
	{
		n: "04",
		t: "Edit & Colour",
		d: "Hand-crafted edit, cinematic colour grade, original sound design and music licensing."
	},
	{
		n: "05",
		t: "Delivery",
		d: "Private review link, revisions, then 4K masters delivered on a custom drive."
	}
];
var addons = [
	{
		t: "Same-Day Edit",
		d: "A 90-second teaser screened at your reception, edited live on the day.",
		price: "+ ₹65,000"
	},
	{
		t: "Photo Add-On",
		d: "Lead photographer paired with our cinematography team, shared creative direction.",
		price: "+ ₹1,40,000"
	},
	{
		t: "Extra Edit Versions",
		d: "Vertical reels, social cut-downs, and a parents' extended edit.",
		price: "+ ₹35,000"
	},
	{
		t: "Travel Coverage",
		d: "Pre-wedding travel film at a destination of your choice in India.",
		price: "On request"
	}
];
var faqs = [
	{
		q: "How far in advance should we book?",
		a: "Most couples reserve 6–12 months out. Peak winter and December dates close earliest — reach out as soon as your date is set."
	},
	{
		q: "Do you travel for destination weddings?",
		a: "Yes — across India and internationally. Travel and stay are billed at cost on top of the base package."
	},
	{
		q: "What's your turnaround time?",
		a: "Teaser within 3 weeks, full film within 10–14 weeks. Rush delivery is available as an add-on."
	},
	{
		q: "Can we customise a package?",
		a: "Every engagement is bespoke. The starting prices listed are reference points — we'll shape the scope around your day."
	}
];
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Services",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Cinematic work, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "gold-gradient-text font-serif italic font-light",
				children: "end to end."
			})] }),
			subtitle: "Each engagement begins with a conversation. Below are starting points — every film is shaped to your day, venue, and story."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-16 md:py-24 container-x space-y-5 md:space-y-6",
			children: services.map((s, i) => {
				const Icon = s.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group relative grid lg:grid-cols-12 gap-6 lg:gap-8 p-6 sm:p-8 lg:p-12 bg-card rounded-2xl border border-white/[0.06] hover:border-gold/40 transition-all duration-500 hover-lift overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none",
								style: { background: "radial-gradient(600px circle at 30% 0%, rgba(198,169,105,0.08), transparent 50%)" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative lg:col-span-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4 mb-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-12 h-12 grid place-items-center rounded-xl border border-gold/30 bg-gold/5 text-gold group-hover:rotate-6 group-hover:scale-110 transition-transform duration-500",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] tracking-[0.4em] uppercase text-gold",
											children: [
												"0",
												i + 1,
												" · Service"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-3xl sm:text-4xl lg:text-5xl",
										children: s.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground mt-5 leading-relaxed text-[15px]",
										children: s.pitch
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative lg:col-span-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground mb-4",
									children: "Deliverables"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-3",
									children: s.deliverables.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-3 text-[14px] sm:text-[15px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "text-gold mt-1 shrink-0",
											size: 16
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d })]
									}, d))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative lg:col-span-2 flex lg:flex-col lg:items-end justify-between gap-4 pt-4 lg:pt-0 border-t border-white/5 lg:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "lg:text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
										children: "Starting"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl text-gold mt-1",
										children: s.from
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/contact",
									className: "inline-flex items-center gap-2 text-xs tracking-[0.25em] uppercase text-gold border-b border-gold/40 pb-1 hover:border-gold hover:gap-3 transition-all duration-300",
									children: ["Enquire ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 14 })]
								})]
							})
						]
					})
				}, s.title);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative py-20 md:py-32 border-t border-white/[0.06]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 -z-10 opacity-60",
				style: { background: "radial-gradient(ellipse at 50% 0%, rgba(198,169,105,0.06), transparent 60%)" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-3xl mb-14 md:mb-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.4em] uppercase text-gold mb-5",
						children: "The Process"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl md:text-6xl leading-[1.05]",
						children: ["From first call to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif italic gold-gradient-text font-light",
							children: "final cut."
						})]
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid sm:grid-cols-2 lg:grid-cols-5 gap-px bg-white/[0.06] rounded-2xl overflow-hidden",
					children: process.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 80,
						className: "bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group p-7 md:p-8 h-full hover:bg-card transition-colors duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-5xl text-gold/30 group-hover:text-gold transition-colors duration-500",
									children: p.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl mt-6",
									children: p.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground mt-3 leading-relaxed",
									children: p.d
								})
							]
						})
					}, p.n))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "py-20 md:py-32 container-x border-t border-white/[0.06]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between flex-wrap gap-6 mb-12 md:mb-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "Add-ons"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: ["Tailor your ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif italic font-light text-gold",
						children: "package."
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground max-w-md text-[15px]",
					children: "Modular extras to layer onto any service. Mix, match, and shape the engagement to your day."
				})]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid md:grid-cols-2 gap-4 md:gap-5",
				children: addons.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 70,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "group relative p-6 md:p-8 rounded-2xl border border-white/[0.06] bg-card hover:border-gold/40 transition-all duration-500 hover-lift",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "text-gold mt-1 shrink-0 group-hover:rotate-12 transition-transform duration-500",
								size: 18
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4 flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-xl",
										children: a.t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold text-sm tracking-wider",
										children: a.price
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground mt-3 leading-relaxed",
									children: a.d
								})]
							})]
						})
					})
				}, a.t))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "py-20 md:py-32 container-x border-t border-white/[0.06]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-3xl mb-12 md:mb-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "FAQ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: ["Common ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif italic font-light gold-gradient-text",
						children: "questions."
					})]
				})]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-w-3xl mx-auto space-y-3",
				children: faqs.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 60,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqItem, {
						q: f.q,
						a: f.a
					})
				}, f.q))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 md:py-32 container-x",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative rounded-3xl overflow-hidden p-10 sm:p-14 md:p-20 text-center film-grain border border-gold/20",
				style: { background: "radial-gradient(ellipse at top, rgba(198,169,105,0.18), rgba(11,11,11,1) 60%)" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.4em] uppercase text-gold mb-6",
						children: "Ready when you are"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl md:text-6xl lg:text-7xl leading-[1.02] max-w-3xl mx-auto",
						children: [
							"Let's make a film ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif italic font-light gold-gradient-text",
								children: "worth keeping."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-7 max-w-xl mx-auto text-muted-foreground",
						children: "Tell us about your day. We'll respond within 24 hours with a tailored proposal."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "mt-10 inline-flex items-center gap-3 px-8 py-4 bg-gold text-background text-xs tracking-[0.3em] uppercase hover:bg-gold/90 transition-all duration-500 hover:shadow-[0_0_50px_-10px_var(--gold)] gold-pulse rounded-full",
						children: ["Start your enquiry ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })]
					})
				]
			}) })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
function FaqItem({ q, a }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(!open),
		className: "w-full text-left p-6 md:p-7 rounded-2xl border border-white/[0.06] bg-card hover:border-gold/40 transition-colors duration-500",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg md:text-xl",
				children: q
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-9 h-9 shrink-0 grid place-items-center rounded-full border border-gold/40 text-gold",
				children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid transition-all duration-500 ease-out",
			style: {
				gridTemplateRows: open ? "1fr" : "0fr",
				opacity: open ? 1 : 0,
				marginTop: open ? "1rem" : 0
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground leading-relaxed text-[15px]",
					children: a
				})
			})
		})]
	});
}
//#endregion
export { ServicesPage as component };
