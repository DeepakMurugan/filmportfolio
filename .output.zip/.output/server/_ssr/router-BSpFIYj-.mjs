import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BSpFIYj-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Bxsdyus9.css";
var favi_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAADsQAAA7EB9YPtSQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAc9SURBVHic7Z1bbBVFGIA/euFOsSpouEQsEDGCFhUx8uANYzAkSAxeIl4iCiIpAjGKxKiJwQuiPhhTUUFAQcXgDSImQInRQEJUEOUBERKhKSjXcgkIBXz4C7T1HHp2d2b/3Z7/SzZ9OTP/f3a/zpydnZ1pRfOMAL7K4XMthQPACWAfcBKoBQ4C24FtQHX98RewCTimk6YbirQTSCAl9X9Lc/jsMeA34Of64yfgV0SgVGACRKM1cE39cZq9wEpgKbAEaUlSzQjglB2hjuNAFfAQ0DboiU8KJoCbYz8wC7gi2On3S4F2AnlEZ2As8pthCTBANx3BBIifVsBwYD2wCCjTTMYE0KMAGAVsBKYjPyhVkjB0aQtMQ24jy+MObgIkh/7AGuAZYrwuJkCyaAu8CiwG2sUR0ARIJnci4wddfAcyAZLL9cBqoI/PICZAsukDLAcu8hXABEg+vZCBo/Y+KjcB0sEgYC4yiOQUEyA9jAImua7UBEgXr+D4GYIJkC7aAPNxOGxsAqSPcmCqq8pMgHQyFejpoiITIJ20A15wUZEJkF4exsEPQhMgvRQiTw4jYQKkm7uB7lEqSOK08L+B52OO2Qk5F+2RcfeLgb71R3HMuQShGBiH5/MV96zgTT6/TECKkTn/k4DvkBdBtGcXNz124vkfOZ8FaEopUAFsRv/CNzxuCfuF7DdAMPYBbwOXAWOAHbrpnGGkz8qtBchOCfAR+i1ANSGfFFoLEI0DwAPA08iF0KI7cFWYgiaAG14HJijnMDhMIRPAHZXAG4rxTYAEMBV5wUOD68IUMgHcUgdMVIrdjxCDViaAe1YDyxTiFhJiWNgE8MO7SnF7BC1gAvhhGbBHIa4JkBCOA98rxL0waAETwB8/KsQsDFrABPDHZoWYJkCC2KoQ0wRIELUKMQNfTxPAH4cVYh4NWsAE8IfGuT0StIAJ4I9OCjFNgAThbVGHc3AoaAETwB99FWLWBC1gAvjjWoWY1UELmAD+uDnmeCeQdyoCYQL4oS9wZcwxtyLzEQJhAvjhUTys59MMG8IUMgHccwEwXiHu+jCFTAD3TEdnDGBdmEImgFuGIptCxE0d8EOYgiaAO/oAnxJ/3w+wFnlJJTAmgBvKgBVI/6/BirAFTYDoDEGa30sUc/g8bEETIDxtkIWaVgHdFPPYAPwetnASVwhJOkXAvciqHBrj/U1ZEKWwCZA7vYHRyOpcvVQzOcsRYE6UCkyAzHRB+vSBwNXArSTjv70p84DdUSpIkwCvIReiIVuRlbKaMhO4KUDdhchiD8VAV6R/TzongLeiVpImAcpovEkzZN+Pt3eGz7Y0ZgN/RK3E7gLSySHgRRcVmQDpZDqOFqgyAdLHOhyuRGICpIt/gQeRl0+dYAKki4lEGPXLhAmQHuYB77mu1ARIB1V4mmdgAiSftchewsd8VG4CJJtfgGHAQV8BTIDksgpZBXyvzyAmQDJZgPzne19jwARIFnXIaqOjkXt+76TpYVBLZwsyyLM6zqDWAuhzCrm/Lyfmiw/WAmizBtmPaK1WAtYC6LAFuA+ZUax28cFagLjZCMwAFhLiTV4fmAD+qQOWIgtILwdO6qbTGBPAP/cAX2gnkQ37DeCfGUBH7SSyYQL4pzcyhSuRmADxUAHcrp1EJkyAeGiFTOMu1U4kDEnZObQDcgIbHiVZPtsxw2dLkQ2gNXf4jPQalxZJEcAF3ZDHq5oS3OXx+wUm37qAGuAp5Rwq0VlGNiP5JgBIM/ytYvwuwCzF+I3IRwEAHkO2gtdiBHC/Yvwz5KsANcBk5RzeAXoq55C3AoDMs/9SMX5npDvSWFXsDPksAMiW714nXTbDUGCcYvy8F2AH8KRyDjNRXH0k3wUA+Bjdp3UdgLmE2PLNBSaA8DiwSzH+DcAUjcAmgLALmZunyUvAgLiDmgBnWQgsVozfBpgPtI4zqAnQmPHAP4rxy4Hn4gxoAjRmF7IIgybPAoPjCmYC/J/PiLD4sgOKkLuCdnEEMwEy8wQhduBySD/g5TgCmQCZ2Y3yCB3SFXnfes4EyM7XwCLF+AXIs4Jss56cBTGyMwHdrqAX8KbPACbAudmNziZQDRkDDPdVuQnQPN8AnyjnMBtZxdw5JkBuVAA7FeN3Rd4tdI4JkBt70O8KRiJb1TjFBMidJcijY00qgR4uKzQBglEBVCvGPw/H08hMgGDsR2dj6IbchuxOHhst6c0gV8xD9+2iQ8hWtZGxFiAcE4HtivGdTSMzAcJRiwzQnFLMYQgxTWi1LiA7c9DtCo4C/aN8AWsBojEZ3a7g9DSy4rAVmADRqAUeQbcrGAhM8xnAuoDm+QDdruA4MChM4tYCuGEKsE0xfhFyaxp4GpkJ4IYD6HcFlyPvFgTCBHDHSuB95RwmAzcGKWACuGUKsqO5FgXAh0CnIAUMdxxGVh/R7AouRd44zgkTwD1V6K8BNBa4w1VldhsYnA7An+jeGtYA5zeX6H/8E7BcLbLQiwAAAABJRU5ErkJggg==";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var WHATSAPP_NUMBER = "919800000000";
function FloatingWhatsApp() {
	const [show, setShow] = (0, import_react.useState)(false);
	const [pulse, setPulse] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setShow(true), 800);
		return () => clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hi! I'd love to talk about my wedding film.")}`,
		target: "_blank",
		rel: "noopener noreferrer",
		"aria-label": "Chat on WhatsApp",
		onClick: () => setPulse(false),
		className: `fixed z-[70] bottom-4 right-4 sm:bottom-6 sm:right-6 transition-all duration-500 ${show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative grid place-items-center w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-br from-[#25D366] to-[#128C7E] shadow-[0_10px_30px_-8px_rgba(37,211,102,0.55)] group-hover:scale-110 active:scale-95 transition-transform",
			children: [pulse && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full bg-[#25D366]/60 animate-ping" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full bg-[#25D366]/30 animate-pulse" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 32 32",
				className: "relative z-10 w-6 h-6 sm:w-7 sm:h-7 text-white",
				fill: "currentColor",
				"aria-hidden": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.11 17.24c-.28-.14-1.66-.82-1.92-.91-.26-.1-.45-.14-.63.14-.19.28-.72.91-.88 1.1-.16.19-.32.21-.6.07-.28-.14-1.18-.44-2.25-1.39-.83-.74-1.39-1.65-1.55-1.93-.16-.28-.02-.43.12-.57.13-.13.28-.32.42-.49.14-.16.19-.28.28-.47.09-.19.05-.35-.02-.49-.07-.14-.63-1.52-.86-2.08-.23-.55-.46-.47-.63-.48l-.54-.01c-.19 0-.49.07-.75.35-.26.28-.98.96-.98 2.35s1 2.72 1.14 2.91c.14.19 1.97 3 4.77 4.21.67.29 1.19.46 1.6.59.67.21 1.28.18 1.76.11.54-.08 1.66-.68 1.9-1.33.24-.65.24-1.21.17-1.33-.07-.12-.26-.19-.54-.33zM16.02 4C9.4 4 4.05 9.35 4.05 15.97c0 2.11.55 4.17 1.6 5.99L4 28l6.19-1.61a11.9 11.9 0 0 0 5.82 1.49h.01c6.62 0 11.98-5.35 11.98-11.97 0-3.2-1.25-6.2-3.5-8.46A11.9 11.9 0 0 0 16.02 4z" })
			})]
		})
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$7 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "j" },
			{
				name: "description",
				content: "Documentary-style wedding cinematographer in Chennai crafting cinematic films with FPV drone visuals and emotional storytelling."
			},
			{
				name: "author",
				content: "Rajendraprasath Films"
			},
			{
				property: "og:title",
				content: "j"
			},
			{
				property: "og:description",
				content: "Documentary-led wedding films crafted with cinematic storytelling, emotion, and timeless visual elegance."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Rajendraprasath Films"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "j"
			},
			{
				name: "description",
				content: "A premium portfolio website showcasing cinematic wedding films and services."
			},
			{
				property: "og:description",
				content: "A premium portfolio website showcasing cinematic wedding films and services."
			},
			{
				name: "twitter:description",
				content: "A premium portfolio website showcasing cinematic wedding films and services."
			},
			{
				property: "og:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2322dee8-0f40-4cd7-a377-e3d5cb7a0a8c/id-preview-c6a49567--885eb323-5dd5-48b0-9ef4-36b1434aaef1.lovable.app-1782995441035.png"
			},
			{
				name: "twitter:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2322dee8-0f40-4cd7-a377-e3d5cb7a0a8c/id-preview-c6a49567--885eb323-5dd5-48b0-9ef4-36b1434aaef1.lovable.app-1782995441035.png"
			}
		],
		links: [
			{
				rel: "icon",
				href: favi_default,
				type: "image/png"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300;1,9..144,400&display=swap"
			},
			{
				rel: "stylesheet",
				href: "https://api.fontshare.com/v2/css?f[]=clash-display@400,500,600,700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$7.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingWhatsApp, {})]
	});
}
var BASE_URL = "";
var Route$6 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const xml = [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
		...[
			{
				path: "/",
				changefreq: "weekly",
				priority: "1.0"
			},
			{
				path: "/about",
				changefreq: "monthly",
				priority: "0.8"
			},
			{
				path: "/portfolio",
				changefreq: "weekly",
				priority: "0.9"
			},
			{
				path: "/services",
				changefreq: "monthly",
				priority: "0.9"
			},
			{
				path: "/experience",
				changefreq: "monthly",
				priority: "0.7"
			},
			{
				path: "/contact",
				changefreq: "yearly",
				priority: "0.7"
			}
		].map((e) => [
			`  <url>`,
			`    <loc>${BASE_URL}${e.path}</loc>`,
			e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
			e.priority ? `    <priority>${e.priority}</priority>` : null,
			`  </url>`
		].filter(Boolean).join("\n")),
		`</urlset>`
	].join("\n");
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$5 = () => import("./services-DeG3dm2I.mjs");
var Route$5 = createFileRoute("/services")({
	head: () => ({
		meta: [
			{ title: "Services — Wedding Films, Pre-Wedding, Drone Cinematography" },
			{
				name: "description",
				content: "Wedding films, pre-wedding shoots, FPV drone cinematography, commercial and event coverage in Chennai and across India."
			},
			{
				property: "og:title",
				content: "Services — Wedding Films, Pre-Wedding, Drone Cinematography"
			},
			{
				property: "og:description",
				content: "Premium cinematography services in Chennai. Wedding, pre-wedding, drone, commercial, events."
			},
			{
				property: "og:url",
				content: "/services"
			}
		],
		links: [{
			rel: "canonical",
			href: "/services"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./portfolio-Vadii1N5.mjs");
var Route$4 = createFileRoute("/portfolio")({
	head: () => ({
		meta: [
			{ title: "Portfolio — Cinematic Wedding Films in Chennai" },
			{
				name: "description",
				content: "A curated selection of wedding films, pre-wedding shoots, FPV drone, commercial and concert cinematography."
			},
			{
				property: "og:title",
				content: "Portfolio — Cinematic Wedding Films in Chennai"
			},
			{
				property: "og:description",
				content: "Selected wedding films and cinematic work by Rajendraprasath."
			},
			{
				property: "og:url",
				content: "/portfolio"
			}
		],
		links: [{
			rel: "canonical",
			href: "/portfolio"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./experience-panhyaE2.mjs");
var Route$3 = createFileRoute("/experience")({
	head: () => ({
		meta: [
			{ title: "Experience & Gear — Cinema Cameras, Drones, Workflow" },
			{
				name: "description",
				content: "Cameras, lenses, drones, audio and post-production workflow used by Rajendraprasath Films."
			},
			{
				property: "og:title",
				content: "Experience & Gear — Cinema Cameras, Drones, Workflow"
			},
			{
				property: "og:description",
				content: "A look behind the lens — gear, drones, and workflow."
			},
			{
				property: "og:url",
				content: "/experience"
			}
		],
		links: [{
			rel: "canonical",
			href: "/experience"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./contact-CRzr296g.mjs");
var Route$2 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: "Contact — Book a Wedding Cinematographer in Chennai" },
			{
				name: "description",
				content: "Book Rajendraprasath Films for your wedding, pre-wedding or commercial shoot in Chennai and beyond."
			},
			{
				property: "og:title",
				content: "Contact — Book a Wedding Cinematographer in Chennai"
			},
			{
				property: "og:description",
				content: "Your story deserves to be filmed beautifully. Start here."
			},
			{
				property: "og:url",
				content: "/contact"
			}
		],
		links: [{
			rel: "canonical",
			href: "/contact"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./about-DI_3I4HT.mjs");
var Route$1 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: "About — Rajendraprasath, Chennai Wedding Filmmaker" },
			{
				name: "description",
				content: "Meet Rajendraprasath — a Chennai-based wedding cinematographer with 8+ years crafting documentary, cinematic, FPV-led wedding films."
			},
			{
				property: "og:title",
				content: "About — Rajendraprasath, Chennai Wedding Filmmaker"
			},
			{
				property: "og:description",
				content: "Documentary-led wedding films, 8+ years of craft, Chennai-based, available worldwide."
			},
			{
				property: "og:url",
				content: "/about"
			}
		],
		links: [{
			rel: "canonical",
			href: "/about"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./routes-CGpp2lb0.mjs");
var Route = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Best Wedding Cinematographer in Chennai | Rajendraprasath Films" },
			{
				name: "description",
				content: "Documentary-style wedding filmmaker in Chennai creating cinematic films with FPV drone visuals and emotional storytelling."
			},
			{
				property: "og:title",
				content: "Best Wedding Cinematographer in Chennai | Rajendraprasath Films"
			},
			{
				property: "og:description",
				content: "Documentary-style wedding filmmaker in Chennai creating cinematic films with FPV drone visuals and emotional storytelling."
			},
			{
				property: "og:url",
				content: "/"
			}
		],
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var SitemapDotxmlRoute = Route$6.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$7
});
var ServicesRoute = Route$5.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$7
});
var PortfolioRoute = Route$4.update({
	id: "/portfolio",
	path: "/portfolio",
	getParentRoute: () => Route$7
});
var ExperienceRoute = Route$3.update({
	id: "/experience",
	path: "/experience",
	getParentRoute: () => Route$7
});
var ContactRoute = Route$2.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$7
});
var AboutRoute = Route$1.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$7
});
var rootRouteChildren = {
	IndexRoute: Route.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	AboutRoute,
	ContactRoute,
	ExperienceRoute,
	PortfolioRoute,
	ServicesRoute,
	SitemapDotxmlRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
