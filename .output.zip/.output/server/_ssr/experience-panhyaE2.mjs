import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as Camera, g as Layers, l as Plane, r as WandSparkles } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as PageHero } from "./PageHero-vruvWOX5.mjs";
import { t as Reveal } from "./Reveal-hdzIZTDg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/experience-panhyaE2.js
var import_jsx_runtime = require_jsx_runtime();
var cameras = [
	{
		name: "Sony Alpha 7 IV",
		spec: "33MP · 4K 60p · S-Cinetone"
	},
	{
		name: "Sony FX3",
		spec: "Full-frame cinema · Dual base ISO"
	},
	{
		name: "Sony A7S III",
		spec: "Low-light king · 4K 120p"
	}
];
var lenses = [
	{
		name: "Sony 24-70mm GM II",
		spec: "Workhorse zoom"
	},
	{
		name: "Sigma 35mm f/1.4 DG DN",
		spec: "Documentary prime"
	},
	{
		name: "Sony 85mm f/1.4 GM",
		spec: "Portrait & emotion"
	},
	{
		name: "Sony 16-35mm GM",
		spec: "Wide & venue"
	}
];
var drones = [{
	name: "DJI FPV Avata 2",
	spec: "Cinewhoop · 4K 100fps"
}, {
	name: "DJI Mavic 3 Cine",
	spec: "ProRes · Hasselblad CMOS"
}];
var audio = [{
	name: "RØDE Wireless GO II",
	spec: "Dual channel · 32-bit float"
}, {
	name: "Sennheiser MKH 416",
	spec: "Shotgun reference"
}];
function GearList({ title, items, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group p-8 rounded-2xl border border-white/[0.06] bg-card hover:border-gold/40 transition-all duration-500 hover-lift gold-sheen relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none",
				style: { background: "radial-gradient(circle at 0% 0%, rgba(198,169,105,0.12), transparent 60%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 mb-6 relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-11 h-11 grid place-items-center rounded-xl border border-gold/30 bg-gold/5 text-gold group-hover:rotate-6 transition-transform duration-500",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl",
					children: title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-white/[0.05] relative",
				children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[15px]",
						children: i.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground text-right",
						children: i.spec
					})]
				}, i.name))
			})
		]
	}) });
}
var workflow = [
	{
		t: "Pre-Production",
		d: "Treatment, mood reel, shot list, venue recce, contingency plans."
	},
	{
		t: "Production",
		d: "Two-camera principal + B-cam + drone team. Dedicated audio."
	},
	{
		t: "Post — Edit",
		d: "DaVinci Resolve · narrative pacing · music-led storytelling."
	},
	{
		t: "Post — Grade",
		d: "ACES-based pipeline · cinema LUTs · per-shot finishing."
	},
	{
		t: "Delivery",
		d: "4K master, social cutdowns, archive backup for 2 years."
	}
];
function ExperiencePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Experience & Gear",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"The ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gold-gradient-text italic font-light",
					children: "craft"
				}),
				" behind the camera."
			] }),
			subtitle: "Premium gear is the floor, not the ceiling. The films come from the people, the planning, and the post."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y container-x grid md:grid-cols-2 gap-5 md:gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearList, {
					title: "Cinema Bodies",
					items: cameras,
					icon: Camera
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearList, {
					title: "Lenses",
					items: lenses,
					icon: Layers
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearList, {
					title: "Drones",
					items: drones,
					icon: Plane
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearList, {
					title: "Audio",
					items: audio,
					icon: WandSparkles
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-y section-gold-veil border-y border-white/[0.05]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-x",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.4em] uppercase text-gold mb-4",
					children: "Workflow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl lg:text-6xl mb-12 md:mb-16",
					children: "From brief to delivery."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid sm:grid-cols-2 md:grid-cols-5 gap-px bg-white/[0.06] rounded-2xl overflow-hidden",
					children: workflow.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 80,
						className: "bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group p-7 md:p-8 min-h-[200px] h-full hover:bg-card transition-colors duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-4xl text-gold/40 group-hover:text-gold transition-colors duration-500",
									children: ["0", i + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl mt-6",
									children: w.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground mt-2 leading-relaxed",
									children: w.d
								})
							]
						})
					}, w.t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
//#endregion
export { ExperiencePage as component };
