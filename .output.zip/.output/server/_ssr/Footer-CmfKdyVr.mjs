import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Instagram, a as Send, h as Mail, m as MapPin, n as X, p as Menu, t as Youtube, u as Phone, w as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Footer-CmfKdyVr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		to: "/",
		label: "Home",
		num: "01"
	},
	{
		to: "/about",
		label: "About",
		num: "02"
	},
	{
		to: "/portfolio",
		label: "Films",
		num: "03"
	},
	{
		to: "/services",
		label: "Services",
		num: "04"
	},
	{
		to: "/experience",
		label: "Gear",
		num: "05"
	},
	{
		to: "/contact",
		label: "Contact",
		num: "06"
	}
];
function Nav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 20);
		onScroll();
		window.addEventListener("scroll", onScroll);
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: `fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "bg-background/70 backdrop-blur-2xl border-b border-white/[0.06] shadow-[0_8px_32px_-12px_rgba(0,0,0,0.6)]" : "bg-transparent"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-x flex items-center justify-between h-16 md:h-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "flex items-center gap-2 group relative z-[60]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-lg md:text-xl tracking-tight",
						children: ["Rajendraprasath", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold animate-pulse",
							children: "."
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden lg:flex items-center gap-1",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: l.to,
						className: "group relative px-4 py-2 text-[13px] tracking-wide text-muted-foreground hover:text-foreground transition-colors duration-300",
						activeProps: { className: "text-gold" },
						activeOptions: { exact: l.to === "/" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative z-10",
							children: l.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-4 right-4 bottom-1 h-px bg-gold scale-x-0 origin-left group-hover:scale-x-100 transition-transform duration-500" })]
					}, l.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/contact",
					className: "hidden lg:inline-flex group items-center gap-2 px-5 py-2.5 border border-gold/60 text-gold text-xs tracking-[0.2em] uppercase hover:bg-gold hover:text-background transition-all duration-500 hover:shadow-[0_0_30px_-5px_var(--gold)]",
					children: ["Book Now", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
						size: 14,
						className: "group-hover:rotate-45 transition-transform duration-500"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Toggle menu",
					className: "lg:hidden text-foreground relative z-[60] w-10 h-10 grid place-items-center rounded-full border border-white/10 backdrop-blur-md",
					onClick: () => setOpen(!open),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `lg:hidden fixed inset-0 z-40 transition-all duration-500 ${open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`,
		style: {
			background: "radial-gradient(ellipse at top right, rgba(198,169,105,0.18), transparent 55%), rgba(8,8,8,0.96)",
			backdropFilter: "blur(24px)"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 film-grain" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "relative h-full container-x flex flex-col justify-center gap-1 pt-20",
			children: [links.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: l.to,
				onClick: () => setOpen(false),
				className: "group flex items-baseline gap-4 py-3 border-b border-white/[0.06]",
				style: {
					opacity: open ? 1 : 0,
					transform: open ? "translateY(0)" : "translateY(20px)",
					transition: `opacity 0.6s ease ${i * 60 + 100}ms, transform 0.6s ease ${i * 60 + 100}ms`
				},
				activeProps: { className: "text-gold" },
				activeOptions: { exact: l.to === "/" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] tracking-[0.3em] text-gold/70 w-8",
						children: l.num
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-4xl sm:text-5xl tracking-tight group-hover:text-gold group-hover:translate-x-2 transition-all duration-500",
						children: l.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
						size: 20,
						className: "ml-auto text-muted-foreground opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-500"
					})
				]
			}, l.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-col gap-3 text-xs text-muted-foreground tracking-wider",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "hello@rajendraprasath.films" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+91 98000 00000 · Chennai, India" })]
			})]
		})]
	})] });
}
var nav = [
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/portfolio",
		label: "Films"
	},
	{
		to: "/services",
		label: "Services"
	},
	{
		to: "/experience",
		label: "Gear"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
var services = [
	"Wedding Films",
	"Pre-Wedding",
	"FPV Drone",
	"Commercial",
	"Same-Day Edit"
];
var wordmarkStyle = {
	background: "linear-gradient(180deg, rgba(198,169,105,0.22) 0%, rgba(198,169,105,0.04) 92%)",
	WebkitBackgroundClip: "text",
	backgroundClip: "text",
	color: "transparent"
};
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative mt-32 overflow-hidden border-t border-white/[0.06] bg-[oklch(0.06_0_0)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute -top-40 left-1/2 -translate-x-1/2 w-[70rem] h-[36rem] rounded-full blur-[120px] opacity-[0.18] pointer-events-none",
				style: { background: "radial-gradient(circle, var(--gold), transparent 60%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-x-0 top-0 h-px",
				style: { background: "linear-gradient(90deg, transparent, rgba(198,169,105,0.6), transparent)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 film-grain opacity-60 pointer-events-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative container-x pt-20 md:pt-28 pb-14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid lg:grid-cols-12 gap-10 lg:gap-16 items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] tracking-[0.4em] uppercase text-gold mb-6 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-8 h-px bg-gold/60" }), " Let's create something timeless"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02]",
							children: [
								"Your story,",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-serif italic font-light gold-gradient-text",
									children: "beautifully"
								}),
								" ",
								"filmed."
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-4 flex lg:justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							className: "group inline-flex items-center gap-3 px-7 py-4 rounded-full bg-gold text-gold-foreground text-xs tracking-[0.25em] uppercase hover:bg-gold/90 transition-all shadow-[0_20px_50px_-15px_rgba(198,169,105,0.6)]",
							children: ["Start a project", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								size: 16,
								className: "group-hover:rotate-45 transition-transform duration-500"
							})]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative container-x",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative container-x py-14 md:py-16 grid grid-cols-2 md:grid-cols-12 gap-10 md:gap-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-2 md:col-span-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "inline-flex items-baseline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-3xl md:text-4xl tracking-tight",
									children: ["Rajendraprasath", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gold",
										children: "."
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground max-w-md leading-relaxed mt-5 text-[15px]",
								children: "Documentary-led wedding films crafted with cinematic storytelling, emotion, and timeless visual elegance. Based in Chennai. Available worldwide."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: (e) => e.preventDefault(),
								className: "mt-8 flex items-center gap-2 max-w-md rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-md p-1.5 pl-5 focus-within:border-gold/60 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									placeholder: "Your email for stories & updates",
									className: "flex-1 bg-transparent outline-none text-sm text-foreground placeholder:text-muted-foreground/70 py-2"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									"aria-label": "Subscribe",
									className: "w-10 h-10 rounded-full bg-gold text-gold-foreground grid place-items-center hover:scale-105 active:scale-95 transition-transform",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 15 })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-3 mt-8",
								children: [{
									Icon: Instagram,
									label: "Instagram",
									href: "#"
								}, {
									Icon: Youtube,
									label: "YouTube",
									href: "#"
								}].map(({ Icon, label, href }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href,
									"aria-label": label,
									className: "group relative w-11 h-11 grid place-items-center rounded-full border border-white/10 hover:border-gold hover:text-gold transition-all duration-500 overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-gold/10 scale-0 group-hover:scale-100 transition-transform duration-500 rounded-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										size: 16,
										className: "relative"
									})]
								}, label))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-5",
							children: "Navigate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3 text-sm text-muted-foreground",
							children: nav.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: l.to,
								className: "link-gold inline-flex items-center gap-2 hover:text-foreground transition-colors",
								children: l.label
							}) }, l.to))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-5",
							children: "Services"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3 text-sm text-muted-foreground",
							children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "hover:text-foreground transition-colors",
								children: s
							}, s))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-2 md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-5",
							children: "Contact"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "space-y-3 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:hello@rajendraprasath.films",
									className: "flex items-center gap-2 hover:text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
										size: 13,
										className: "text-gold"
									}), " hello@rajendraprasath.films"]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "tel:+919800000000",
									className: "flex items-center gap-2 hover:text-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
										size: 13,
										className: "text-gold"
									}), " +91 98000 00000"]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
										size: 13,
										className: "text-gold"
									}), " Chennai, India"]
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden select-none pointer-events-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 z-10 bg-[linear-gradient(90deg,oklch(0.06_0_0)_0%,transparent_10%,transparent_90%,oklch(0.06_0_0)_100%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "footer-marquee flex w-max items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "whitespace-nowrap px-6 text-center font-display leading-none tracking-[-0.04em] text-[clamp(4rem,12vw,12rem)] lg:text-[clamp(7rem,16vw,18rem)]",
								style: wordmarkStyle,
								children: "Rajendraprasath"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "whitespace-nowrap px-6 text-center font-display leading-none tracking-[-0.04em] text-[clamp(4rem,12vw,12rem)] lg:text-[clamp(7rem,16vw,18rem)]",
								style: wordmarkStyle,
								children: "Rajendraprasath"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden text-center font-display leading-none tracking-[-0.04em] text-[clamp(4rem,18vw,8rem)]",
						style: wordmarkStyle,
						children: "Rajendraprasath"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative border-t border-white/[0.06]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container-x py-6 flex flex-col md:flex-row justify-between gap-3 text-[11px] tracking-wider text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Rajendraprasath Films — All rights reserved."
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline text-white/20",
							children: "•"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://dtechgrow.com",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 uppercase tracking-[0.28em] text-white/80 transition-all duration-300 hover:border-gold/50 hover:text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-gold/80" }), "Powered by DTechGrow"]
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { Nav as n, Footer as t };
