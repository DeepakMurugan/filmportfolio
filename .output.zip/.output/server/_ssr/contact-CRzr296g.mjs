import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Mail, m as MapPin, u as Phone, x as Check } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as PageHero } from "./PageHero-vruvWOX5.mjs";
import { t as Reveal } from "./Reveal-hdzIZTDg.mjs";
import { n as objectType, r as stringType, t as literalType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CRzr296g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var schema = objectType({
	name: stringType().trim().min(2, "Please enter your name").max(80),
	phone: stringType().trim().min(7, "Please enter a phone number").max(20),
	email: stringType().trim().email("Invalid email").max(150),
	date: stringType().trim().max(40).optional().or(literalType("")),
	location: stringType().trim().max(100).optional().or(literalType("")),
	budget: stringType().trim().max(40).optional().or(literalType("")),
	message: stringType().trim().min(10, "Please share a few words").max(1500)
});
function ContactPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	function onSubmit(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const data = Object.fromEntries(fd.entries());
		const parsed = schema.safeParse(data);
		if (!parsed.success) {
			const errs = {};
			parsed.error.issues.forEach((i) => {
				errs[i.path[0]] = i.message;
			});
			setErrors(errs);
			return;
		}
		setErrors({});
		setSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Get in Touch",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Your story deserves to be ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "gold-gradient-text italic font-light",
				children: "filmed beautifully."
			})] }),
			subtitle: "Share a few details. I respond personally within 24 hours."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section-y container-x grid lg:grid-cols-12 gap-12 lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "lg:col-span-5 space-y-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.4em] uppercase text-gold mb-3",
							children: "Studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl",
							children: "Chennai, India"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground mt-2",
							children: "Available across India · Destination weddings worldwide"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "mailto:hello@rajendraprasath.films",
								className: "flex items-center gap-4 group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-12 h-12 grid place-items-center border border-border group-hover:border-gold group-hover:text-gold transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 16 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-foreground group-hover:text-gold transition-colors",
									children: "hello@rajendraprasath.films"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "tel:+919800000000",
								className: "flex items-center gap-4 group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-12 h-12 grid place-items-center border border-border group-hover:border-gold group-hover:text-gold transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 16 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-foreground group-hover:text-gold transition-colors",
									children: "+91 98000 00000"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-12 h-12 grid place-items-center border border-border",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
										size: 16,
										className: "text-gold"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
									children: "Studio"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Anna Nagar, Chennai 600040" })] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "glass-card p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-3",
							children: "Booking Window"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[15px] text-muted-foreground leading-relaxed",
							children: "I take on a limited number of weddings per year. Enquire 4–8 months ahead for peak season (Nov–Feb)."
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 150,
				className: "lg:col-span-7",
				children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-gold/40 bg-card p-12 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-16 h-16 mx-auto rounded-full bg-gold/10 grid place-items-center text-gold mb-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 28 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl",
							children: "Message received."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground mt-4 max-w-md mx-auto",
							children: "Thank you. I'll personally read every word and reply within 24 hours."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "space-y-6 p-8 lg:p-10 border border-border bg-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name",
								name: "name",
								error: errors.name,
								required: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								name: "phone",
								type: "tel",
								error: errors.phone,
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							name: "email",
							type: "email",
							error: errors.email,
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Event Date",
								name: "date",
								type: "date",
								error: errors.date
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Location",
								name: "location",
								error: errors.location
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Budget Range (optional)",
							name: "budget",
							placeholder: "e.g. ₹2L – ₹4L",
							error: errors.budget
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
								children: "Tell me about your story *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								name: "message",
								rows: 5,
								className: "mt-3 w-full bg-transparent border-b border-border focus:border-gold outline-none py-3 text-foreground placeholder:text-muted-foreground/50 resize-none transition-colors",
								placeholder: "Where, when, what kind of film you imagine..."
							}),
							errors.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-destructive text-xs mt-2",
								children: errors.message
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "w-full md:w-auto inline-flex items-center justify-center gap-3 px-10 py-4 bg-gold text-gold-foreground text-sm tracking-[0.25em] uppercase hover:bg-gold/90 transition-all",
							children: "Send Enquiry"
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
function Field({ label, name, type = "text", error, required, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "text-[10px] tracking-[0.3em] uppercase text-muted-foreground",
			children: [
				label,
				" ",
				required && "*"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			type,
			placeholder,
			className: "mt-3 w-full bg-transparent border-b border-border focus:border-gold outline-none py-3 text-foreground placeholder:text-muted-foreground/50 transition-colors"
		}),
		error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-destructive text-xs mt-2",
			children: error
		})
	] });
}
//#endregion
export { ContactPage as component };
