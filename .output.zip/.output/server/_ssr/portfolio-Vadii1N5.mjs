import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { c as Play, n as X } from "../_libs/lucide-react.mjs";
import { n as Nav, t as Footer } from "./Footer-CmfKdyVr.mjs";
import { t as PageHero } from "./PageHero-vruvWOX5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-Vadii1N5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var categories = [
	"All",
	"Wedding",
	"Pre-Wedding",
	"Drone",
	"Commercial",
	"Concert"
];
var works = [
	{
		title: "Ananya & Rohan",
		category: "Wedding",
		img: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80",
		span: "tall",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Priya & Karthik",
		category: "Pre-Wedding",
		img: "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=1200&q=80",
		span: "wide",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Aerial Symphony",
		category: "Drone",
		img: "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=1200&q=80",
		span: "sq",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Tanishq Heritage",
		category: "Commercial",
		img: "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=1200&q=80",
		span: "sq",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Coldplay Chennai",
		category: "Concert",
		img: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=1200&q=80",
		span: "wide",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Meera & Arjun",
		category: "Wedding",
		img: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=1200&q=80",
		span: "tall",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Sky over Marina",
		category: "Drone",
		img: "https://images.unsplash.com/photo-1473625247510-8ceb1760943f?w=1200&q=80",
		span: "wide",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Sabyasachi Bridal",
		category: "Commercial",
		img: "https://images.unsplash.com/photo-1612200143130-7bd442b3e5fd?w=1200&q=80",
		span: "sq",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	},
	{
		title: "Aisha & Vikram",
		category: "Pre-Wedding",
		img: "https://images.unsplash.com/photo-1525258946800-98cfd641d0de?w=1200&q=80",
		span: "sq",
		video: "https://www.youtube.com/embed/dQw4w9WgXcQ"
	}
];
var spanClass = {
	tall: "md:row-span-2 aspect-[3/4] md:aspect-auto",
	wide: "md:col-span-2 aspect-[16/10]",
	sq: "aspect-square"
};
function PortfolioPage() {
	const [active, setActive] = (0, import_react.useState)("All");
	const [light, setLight] = (0, import_react.useState)(null);
	const filtered = active === "All" ? works : works.filter((w) => w.category === active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Selected Work",
			title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"A ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "gold-gradient-text italic font-light",
					children: "living "
				}),
				" gallery of moments."
			] }),
			subtitle: "Wedding films, pre-weddings, drone cinematography, commercials and concerts. Filtered by category — open any to view full."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-x py-10 md:py-12 flex flex-wrap gap-3",
			children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setActive(c),
				className: `px-5 py-2.5 text-xs tracking-[0.25em] uppercase border rounded-full transition-all duration-300 ${active === c ? "bg-gold text-gold-foreground border-gold shadow-[0_0_30px_-8px_var(--gold)]" : "border-white/10 text-muted-foreground hover:border-gold hover:text-gold"}`,
				children: c
			}, c))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "container-x pb-24 md:pb-32",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[260px] md:auto-rows-[300px]",
				children: filtered.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setLight(w),
					className: `group relative overflow-hidden rounded-2xl gold-sheen ${spanClass[w.span]}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: w.img,
							alt: w.title,
							loading: "lazy",
							className: "absolute inset-0 w-full h-full object-cover transition-transform duration-[1400ms] group-hover:scale-110"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 opacity-0 group-hover:opacity-100 bg-background/40 transition-opacity grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-14 h-14 rounded-full bg-gold grid place-items-center text-gold-foreground gold-pulse",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									size: 18,
									className: "ml-1",
									fill: "currentColor"
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-0 left-0 p-6 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] tracking-[0.3em] uppercase text-gold mb-1",
								children: w.category
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl",
								children: w.title
							})]
						})
					]
				}, w.title))
			})
		}),
		light && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-[60] bg-background/95 backdrop-blur-xl grid place-items-center p-6",
			onClick: () => setLight(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				"aria-label": "Close",
				className: "absolute top-6 right-6 text-foreground hover:text-gold",
				onClick: () => setLight(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 28 })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-5xl",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-video",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							className: "w-full h-full",
							src: light.video,
							title: light.title,
							allow: "autoplay; encrypted-media",
							allowFullScreen: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] tracking-[0.3em] uppercase text-gold mt-6",
						children: light.category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-3xl mt-2",
						children: light.title
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
//#endregion
export { PortfolioPage as component };
